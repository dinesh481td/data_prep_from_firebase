import os
import subprocess
subprocess.run(['dvc','init'])
# Define the configurations to add/update
config_data = """
[core]
    remote = remote-storage
    autostage = true
    hardlink_lock = true
['remote "remote-storage"']
    url = gs://data-labelling-platform_cloudbuild
"""

# Path to your .dvc directory and config file
dvc_directory = ".dvc"
config_file = os.path.join(dvc_directory, "config")

# Write the configuration data to the config file
with open(config_file, "w") as f:
    f.write(config_data)

print(f"Successfully wrote DVC config to {config_file}")

# Use subprocess to execute DVC commands to set remote and core configurations
try:
    # Set remote URL
    subprocess.run(['dvc', 'remote', 'modify', 'remote-storage', 'url', 'gs://data-labelling-platform_cloudbuild'], check=True)
    print("Remote URL set successfully.")

    # Set core configurations
    subprocess.run(['dvc', 'config', 'core.autostage', 'true'], check=True)
    subprocess.run(['dvc', 'config', 'core.hardlink_lock', 'true'], check=True)
    print("Core configurations updated successfully.")
    subprocess.run(['dvc', 'pull', 'Dataset.dvc'], check=True)
except subprocess.CalledProcessError as e:
    print(f"Error executing DVC command: {e}")
